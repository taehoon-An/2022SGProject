import java.util.Vector;

import Value.VLecture;

public class PSincheongPanel extends PLectureTable {
	private static final long serialVersionUID = 1L;

	public PSincheongPanel() {

	}

	public Vector<VLecture> getSelectedLectures() {
		// TODO Auto-generated method stub
		return null;
	}

	public void addLectures(Vector<VLecture> lectures) {
		// TODO Auto-generated method stub

	}
}
